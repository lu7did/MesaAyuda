const secretAccessKey="GIj5axa8ZJ7KaANJewudvpEalsWIvYtGVQU5n6V0";
module.exports=secretAccessKey;
