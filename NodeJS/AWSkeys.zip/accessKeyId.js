const accessKeyId = "AKIAQIIDXT4ZX3B7T5EL";
module.exports = accessKeyId;
