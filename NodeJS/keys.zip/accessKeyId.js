const accessKeyId = "AKIAQIIDXT4ZZMR27V4Y";
module.exports = accessKeyId;
