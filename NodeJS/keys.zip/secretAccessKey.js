//const secretAccessKey="HdHRyvRySA2OjcD17w4YgS7a+SK/PWk3In8NZSiA";
const secretAccessKey="d9f8jFK6cU1grREaAQDrwjwrR2GOXa8on60fej1M";
module.exports=secretAccessKey;
