/* Estas son las credenciales AWS de cuenta UADER */
module.exports={
let awsConfig = {
    "region": "us-east-1",
    "endpoint": "http://dynamodb.us-east-1.amazonaws.com",
    "accessKeyId": "AKIAQIIDXT4Z3L6W3LNR", "secretAccessKey": "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"
};
}

